// Jamaree Jackson
// 5/21/19

public class sampleClass
{
  int x = 5;
 
  public static void main(string[] args)
  {
    
    sampleClass myObj = new sampleClass();
    sampleClass myObj2 = new sampleClass();
    
    myObj.x =8;
    
    system.out.println(myObj.x);
    system.out.println(myObj2.x);
  }
}