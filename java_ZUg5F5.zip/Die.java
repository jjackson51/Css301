// Jamaree Jackson
// 5/21/19
public class Die
{
  private int lastValue;
  private ArrayList<Interger> die_list= new Arraylist<Interger>(8);
  
  public int roll()
  {
    lastValue = (int) (math.random() *6) + 1;
    die_list.add(lastValue);
    return LastValue;
  }
  
  public static void main(String[] args)
  {
     Die d = new Die();
    for (int i = 0; i <10; i++)
    {
      system.out.println(d.roll());
    }
  }
}